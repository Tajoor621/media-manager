# Welcome to Media Manager

Luxury file manager for every format on this device.

## What you can do
- Browse Internal Storage (works everywhere, even offline)
- Open a real device folder in Chromium (File System Access)
- Preview images, video, audio, PDF, text, hex, zip, and SQLite
- Crop and rotate photos, build an audio queue, extract archives
- Share via the system share sheet or Nearby (WebRTC)

## Places
Photos, Videos, Music, Documents, Archives, Favorites, Recents, Trash.

Enjoy the gold standard.
